from django import forms

class word(forms.Form):
    word = forms.CharField()