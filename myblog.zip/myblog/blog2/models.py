from django.db import models

class word(models.Model):
    word = models.CharField(max_length=100)



